
# to run 
npx live-server public --port=3000
## Folder Structure
```
dementia-care-tracker/
├── public/
│   ├── index.html              ← Login / Register page
│   ├── dashboard.html          ← Patient dashboard
│   ├── tasks.html              ← Task manager
│   ├── games.html              ← 3 sequential games
│   ├── scores.html             ← Score history + chart
│   ├── caretaker.html          ← Caretaker dashboard
│   └── firebase-messaging-sw.js ← FCM service worker
├── src/
│   ├── css/main.css
│   └── js/
│       ├── firebase-init.js    ← Firebase config
│       ├── fcm.js              ← Push notification setup
│       ├── auth.js
│       ├── utils.js
│       ├── dashboard.js
│       ├── tasks.js
│       ├── games.js
│       ├── scores.js
│       └── caretaker.js
├── functions/
│   ├── index.js                ← Cloud Functions (Twilio + FCM)
│   └── package.json
├── firebase.json
├── firestore.rules
├── firestore.indexes.json
└── package.json
```

---

## Step 1 — Firebase Setup

1. Go to https://console.firebase.google.com → **Create project**
2. Enable these services:
   - **Authentication** → Email/Password
   - **Firestore Database** → Start in production mode
   - **Realtime Database** (optional)
   - **Cloud Messaging**
   - **Hosting**
   - **Functions** (requires Blaze plan for scheduled functions)

3. Get your Firebase config:
   - Project Settings → General → Your apps → Web app → Copy config

4. Replace config in **3 files**:
   - `src/js/firebase-init.js`
   - `public/firebase-messaging-sw.js`
   - `functions/index.js` (not needed — uses admin SDK)

5. Get VAPID key:
   - Project Settings → Cloud Messaging → Web Push certificates → Generate key pair
   - Paste in `src/js/fcm.js` → `VAPID_KEY`

---

## Step 2 — Twilio Setup

1. Sign up at https://www.twilio.com
2. Go to **Messaging → Try it out → Send a WhatsApp message**
3. Join sandbox: send `join <your-word>` to `+14155238886`
4. Get your credentials:
   - Account SID
   - Auth Token
   - Sandbox number: `whatsapp:+14155238886`

5. Set Firebase function config:
```bash
firebase functions:config:set \
  twilio.sid="ACxxxxxxxxxxxxxxxx" \
  twilio.token="your_auth_token" \
  twilio.from="whatsapp:+14155238886"
```

> For production: upgrade Twilio and use an approved WhatsApp Business number.

---

## Step 3 — Install & Run Locally

```bash
# Install Firebase CLI
npm install -g firebase-tools

# Login
firebase login

# Install dependencies
npm install
cd functions && npm install && cd ..

# Run local dev server (no backend)
npm run dev
# → Opens http://localhost:3000

# OR run with Firebase emulators (full backend)
npm run emulate
```

---

## Step 4 — Deploy

```bash
# Deploy everything
firebase deploy

# Deploy only hosting (fast)
npm run deploy:hosting

# Deploy only functions
npm run deploy:functions
```

---

## Step 5 — Firestore Indexes

When you first query, Firestore will show an error with an index link.
Click the link to auto-create. OR deploy indexes manually:

```bash
firebase deploy --only firestore:indexes
```

---

## Data Structure (Firestore)

```
patients/{uid}
  name, age, email, pastProblems, currentCondition,
  caretakerWhatsApp, caretakerEmail, fcmToken

caretakers/{email}
  email, patients: [uid, uid, ...]

tasks/{taskId}
  uid, name, type, times[], completed, completedAt,
  date, alertSent, createdAt

scores/{scoreId}
  uid, date, game1, game2, game3, total, createdAt

whatsapp_queue/{docId}
  patientUid, type, payload{}, sentAt, createdAt, error
```

---

## Cloud Functions Schedule

| Function | Schedule | Purpose |
|---|---|---|
| `sendMedicineReminders` | Every 1 min | FCM push + WhatsApp at task time |
| `checkMissedTasks` | Every 15 min | Alert if task not done |
| `processWhatsAppQueue` | Every 5 min | Send queued WhatsApp messages |
| `sendDailyReport` | 8PM IST daily | Daily score + task summary |

---

## Game Scoring

| Game | Max Score | How |
|---|---|---|
| Reaction Time | ~1000 | `1000 - reactionTime(ms)` |
| Memory Match | ~200 | `200 - (moves × 5)` |
| Image Recognition | 100 | `20 × correct answers (5 Qs)` |
| **Total** | **~1300** | Sum of all 3 |

---

## WhatsApp Message Formats

**Missed Task Alert:**
```
🚨 CareTrack ALERT
Patient: John Doe
Missed Task: Morning Medicine
Scheduled: 07:30
This task was not completed within 15 minutes.
Please check on the patient immediately.
```

**Daily Report:**
```
📋 CareTrack Daily Report
Date: 2024-01-15
Patient: John Doe (Age 72)

✅ Tasks: 3/4 completed
⚠️ Missed: Evening Medicine

🎮 Cognitive Games:
  ⚡ Reaction: 750
  🧠 Memory: 170
  👁️ Recognition: 80
  📊 Total: 1000

📈 Trend: Improving (+50)
```

---

## Caretaker Login Setup

Caretakers **must first register via patient registration** (enter caretaker email there).
Then use that email to create a Firebase Auth account separately and log in via "Caretaker Login".

For simplest setup: use same email for both patient and caretaker login, just a different tab.

---

## Known Constraints

- Scheduled functions require **Blaze (pay-as-you-go) plan** on Firebase
- Twilio sandbox limits messages to verified numbers only
- FCM requires HTTPS (works on Firebase Hosting, not plain `file://`)
- For local testing of notifications: use `npm run emulate`
