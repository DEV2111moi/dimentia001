// Firebase initialization — replace with your config
const firebaseConfig = {
  apiKey: "AIzaSyDgbMEhDPjJrpq_1mnMiqClGcgSokZsc14",
  authDomain: "dementia-care-459f8.firebaseapp.com",
  projectId: "dementia-care-459f8",
  storageBucket: "dementia-care-459f8.firebasestorage.app",
  messagingSenderId: "377401267196",
  appId: "1:377401267196:web:2f00d36361ce110fef9879",
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();
