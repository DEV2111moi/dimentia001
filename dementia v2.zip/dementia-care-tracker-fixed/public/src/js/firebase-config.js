// =============================
// REPLACE WITH YOUR FIREBASE CONFIG
// =============================
const firebaseConfig = {
  apiKey: "AIzaSyDgbMEhDPjJrpq_1mnMiqClGcgSokZsc14",
  authDomain: "dementia-care-459f8.firebaseapp.com",
  projectId: "dementia-care-459f8",
  storageBucket: "dementia-care-459f8.firebasestorage.app",
  messagingSenderId: "377401267196",
  appId: "1:377401267196:web:2f00d36361ce110fef9879",
  databaseURL: "https://console.firebase.google.com/project/dementia-care-459f8/firestore/databases/-default-/data"
};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();
const rtdb = firebase.database();

// FCM
let messaging = null;
try {
  messaging = firebase.messaging();
} catch (e) {
  console.warn("FCM not supported in this browser");
}

export { auth, db, rtdb, messaging };
