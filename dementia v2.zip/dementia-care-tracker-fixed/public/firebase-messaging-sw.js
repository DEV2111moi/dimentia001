// public/firebase-messaging-sw.js
// Firebase Cloud Messaging Service Worker

importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-messaging-compat.js');

// REPLACE with your config

const firebaseConfig = {
  apiKey: "AIzaSyDgbMEhDPjJrpq_1mnMiqClGcgSokZsc14",
  authDomain: "dementia-care-459f8.firebaseapp.com",
  projectId: "dementia-care-459f8",
  storageBucket: "dementia-care-459f8.firebasestorage.app",
  messagingSenderId: "377401267196",
  appId: "1:377401267196:web:2f00d36361ce110fef9879",
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

const messaging = firebase.messaging();

// Handle background messages
messaging.onBackgroundMessage(payload => {
  const { title, body } = payload.notification;
  self.registration.showNotification(title, {
    body,
    icon: '/icon.png',
    badge: '/badge.png',
    tag: 'caretrack-reminder',
    requireInteraction: true,
    actions: [
      { action: 'done', title: '✅ Mark Done' },
      { action: 'snooze', title: '⏰ Snooze 5min' }
    ]
  });
});

// Notification click handler
self.addEventListener('notificationclick', event => {
  event.notification.close();
  if (event.action === 'done') {
    // Open tasks page
    event.waitUntil(clients.openWindow('/tasks.html'));
  } else {
    event.waitUntil(clients.openWindow('/dashboard.html'));
  }
});
