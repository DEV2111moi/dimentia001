requireAuth('patient');

const uid = sessionStorage.getItem('uid');
const today = todayStr();
const scores = { game1: 0, game2: 0, game3: 0 };
let currentGame = 1;

auth.onAuthStateChanged(async user => {
  if (!user) return;

  // Check if games already done today
  const snap = await db.collection('scores')
    .where('uid', '==', uid)
    .where('date', '==', today)
    .get();

  if (!snap.empty) {
    document.getElementById('gameArea').classList.add('hidden');
    document.getElementById('alreadyDone').classList.remove('hidden');
    return;
  }

  initGame1();
});

function setDot(idx, state) {
  const dot = document.getElementById('dot' + idx);
  dot.className = 'progress-dot ' + state;
}

function nextGame(num) {
  currentGame = num;
  document.querySelectorAll('#game1,#game2,#game3,#gameFinal').forEach(el => el.classList.add('hidden'));
  if (num <= 3) {
    document.getElementById('game' + num).classList.remove('hidden');
    for (let i = 0; i < 3; i++) {
      if (i < num - 1) setDot(i, 'done');
      else if (i === num - 1) setDot(i, 'active');
      else setDot(i, '');
    }
  } else {
    document.getElementById('gameFinal').classList.remove('hidden');
  }
}

// ============================================================
// GAME 1: REACTION TIME TEST
// ============================================================
let reactionState = 'idle'; // idle | waiting | ready | go
let reactionTimer = null;
let reactionStart = 0;
let reactionTimes = [];
let reactionRound = 0;

function initGame1() {
  reactionState = 'idle';
  reactionTimes = [];
  reactionRound = 0;
  startReactionRound();
}

function startReactionRound() {
  if (reactionRound >= 3) {
    const best = Math.min(...reactionTimes);
    scores.game1 = Math.max(0, Math.round(1000 - best));
    document.getElementById('reactionBest').textContent = `Best: ${best}ms → Score: ${scores.game1}`;
    document.getElementById('reactionResult').textContent = '✅ Complete! Moving to next game...';
    setTimeout(() => { nextGame(2); initGame2(); }, 1800);
    return;
  }

  const box = document.getElementById('reactionBox');
  box.className = 'reaction-box wait';
  box.textContent = 'Wait for green...';
  document.getElementById('reactionResult').textContent = `Round ${reactionRound + 1} of 3`;
  reactionState = 'waiting';

  const delay = 1500 + Math.random() * 3000;
  reactionTimer = setTimeout(() => {
    box.className = 'reaction-box go';
    box.textContent = 'TAP NOW!';
    reactionState = 'go';
    reactionStart = Date.now();
  }, delay);
}

function reactionClick() {
  if (reactionState === 'waiting') {
    clearTimeout(reactionTimer);
    document.getElementById('reactionResult').textContent = '⚠️ Too early! Try again.';
    document.getElementById('reactionBox').className = 'reaction-box ready';
    document.getElementById('reactionBox').textContent = 'Wait for green...';
    setTimeout(startReactionRound, 1200);
    return;
  }
  if (reactionState === 'go') {
    const elapsed = Date.now() - reactionStart;
    reactionTimes.push(elapsed);
    reactionRound++;
    document.getElementById('reactionResult').textContent = `⚡ ${elapsed}ms!`;
    document.getElementById('reactionBox').className = 'reaction-box ready';
    document.getElementById('reactionBox').textContent = 'Getting ready...';
    reactionState = 'idle';
    setTimeout(startReactionRound, 1000);
  }
}

// ============================================================
// GAME 2: MEMORY MATCH
// ============================================================
const EMOJIS = ['🍎','🐶','🚗','🌸','🎵','🏠','⭐','🌈'];
let memCards = [];
let memFlipped = [];
let memMatched = 0;
let memMoves = 0;
let memLocked = false;

function initGame2() {
  memCards = [...EMOJIS, ...EMOJIS]
    .sort(() => Math.random() - 0.5)
    .map((e, i) => ({ id: i, emoji: e, flipped: false, matched: false }));
  memFlipped = [];
  memMatched = 0;
  memMoves = 0;
  memLocked = false;
  renderMemory();
}

function renderMemory() {
  const grid = document.getElementById('memoryGrid');
  grid.innerHTML = memCards.map((c, i) => `
    <div class="memory-card ${c.flipped || c.matched ? 'flipped' : ''} ${c.matched ? 'matched' : ''}"
         onclick="flipCard(${i})">
      ${c.flipped || c.matched ? c.emoji : '❓'}
    </div>
  `).join('');
  document.getElementById('memMatched').textContent = memMatched;
  document.getElementById('memMoves').textContent = memMoves;
}

function flipCard(idx) {
  if (memLocked) return;
  const card = memCards[idx];
  if (card.flipped || card.matched) return;
  if (memFlipped.length === 2) return;

  card.flipped = true;
  memFlipped.push(idx);
  renderMemory();

  if (memFlipped.length === 2) {
    memMoves++;
    memLocked = true;
    const [a, b] = memFlipped;
    if (memCards[a].emoji === memCards[b].emoji) {
      memCards[a].matched = memCards[b].matched = true;
      memMatched++;
      memFlipped = [];
      memLocked = false;
      renderMemory();
      if (memMatched === 8) {
        scores.game2 = Math.max(0, 200 - memMoves * 5);
        document.getElementById('memoryResult').textContent = `✅ Done in ${memMoves} moves → Score: ${scores.game2}`;
        setTimeout(() => { nextGame(3); initGame3(); }, 1800);
      }
    } else {
      setTimeout(() => {
        memCards[a].flipped = memCards[b].flipped = false;
        memFlipped = [];
        memLocked = false;
        renderMemory();
      }, 900);
    }
  }
}

// ============================================================
// GAME 3: IMAGE RECOGNITION
// ============================================================
const IMG_QUESTIONS = [
  { emoji: '🍎', question: 'What fruit is this?', correct: 'Apple', options: ['Apple', 'Mango', 'Grape', 'Orange'] },
  { emoji: '🐘', question: 'What animal is this?', correct: 'Elephant', options: ['Horse', 'Elephant', 'Giraffe', 'Tiger'] },
  { emoji: '🌙', question: 'What do you see in the sky at night?', correct: 'Moon', options: ['Sun', 'Star', 'Moon', 'Cloud'] },
  { emoji: '🚑', question: 'What vehicle helps in emergencies?', correct: 'Ambulance', options: ['Bus', 'Taxi', 'Ambulance', 'Train'] },
  { emoji: '📚', question: 'What are these?', correct: 'Books', options: ['Books', 'Boxes', 'Bags', 'Bottles'] },
  { emoji: '🌻', question: 'What flower is this?', correct: 'Sunflower', options: ['Rose', 'Lily', 'Sunflower', 'Tulip'] },
  { emoji: '🎂', question: 'What do we eat on birthdays?', correct: 'Cake', options: ['Pizza', 'Cake', 'Bread', 'Rice'] },
  { emoji: '⌚', question: 'What helps you check the time?', correct: 'Watch', options: ['Phone', 'Calendar', 'Watch', 'Mirror'] },
];

let imgQ = 0;
let imgScore = 0;
let imgAnswered = false;
let imgList = [];

function initGame3() {
  imgQ = 0;
  imgScore = 0;
  imgAnswered = false;
  // Pick 5 random
  imgList = [...IMG_QUESTIONS].sort(() => Math.random() - 0.5).slice(0, 5);
  renderImgQ();
}

function renderImgQ() {
  const q = imgList[imgQ];
  document.getElementById('imgQ').textContent = imgQ + 1;
  document.getElementById('imgScore').textContent = imgScore;
  document.getElementById('imgEmoji').textContent = q.emoji;
  document.getElementById('imgQuestion').textContent = q.question;
  document.getElementById('imgFeedback').textContent = '';
  imgAnswered = false;

  const opts = [...q.options].sort(() => Math.random() - 0.5);
  document.getElementById('imgOptions').innerHTML = opts.map(o => `
    <button class="img-option" onclick="answerImg('${o}', '${q.correct}', this)">${o}</button>
  `).join('');
}

function answerImg(chosen, correct, btn) {
  if (imgAnswered) return;
  imgAnswered = true;

  const all = document.querySelectorAll('.img-option');
  all.forEach(b => b.style.pointerEvents = 'none');

  if (chosen === correct) {
    btn.classList.add('correct');
    imgScore += 20;
    document.getElementById('imgFeedback').textContent = '✅ Correct!';
    document.getElementById('imgFeedback').style.color = 'var(--primary)';
  } else {
    btn.classList.add('wrong');
    document.getElementById('imgFeedback').textContent = `❌ It was ${correct}`;
    document.getElementById('imgFeedback').style.color = '#b91c1c';
    // Highlight correct
    all.forEach(b => { if (b.textContent.trim() === correct) b.classList.add('correct'); });
  }

  setTimeout(() => {
    imgQ++;
    if (imgQ < imgList.length) {
      renderImgQ();
    } else {
      scores.game3 = imgScore;
      document.getElementById('imgFeedback').textContent = `✅ Complete! Score: ${imgScore}`;
      setTimeout(showFinalScore, 1500);
    }
  }, 1200);
}

// ============================================================
// FINAL SCORE
// ============================================================
async function showFinalScore() {
  const total = scores.game1 + scores.game2 + scores.game3;
  document.getElementById('finalG1').textContent = scores.game1;
  document.getElementById('finalG2').textContent = scores.game2;
  document.getElementById('finalG3').textContent = scores.game3;
  document.getElementById('finalTotal').textContent = total;

  nextGame(4);

  // Check yesterday for trend
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yStr = yesterday.toISOString().split('T')[0];
  const ySnap = await db.collection('scores')
    .where('uid', '==', uid)
    .where('date', '==', yStr)
    .get();

  let trendHtml = '';
  if (!ySnap.empty) {
    const yScore = ySnap.docs[0].data().total || 0;
    const diff = total - yScore;
    if (diff > 5) trendHtml = '<span class="badge badge-green" style="font-size:14px">▲ Improving</span>';
    else if (diff < -5) trendHtml = '<span class="badge badge-red" style="font-size:14px">▼ Declining</span>';
    else trendHtml = '<span class="badge badge-gray" style="font-size:14px">→ Stable</span>';
  }
  document.getElementById('trendBadge').innerHTML = trendHtml;

  // Save to Firestore
  await db.collection('scores').add({
    uid,
    date: today,
    game1: scores.game1,
    game2: scores.game2,
    game3: scores.game3,
    total,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  });

  // Trigger daily WhatsApp report
  triggerWhatsApp(uid, 'daily_report', {
    date: today,
    game1: scores.game1,
    game2: scores.game2,
    game3: scores.game3,
    total
  });

  showToast('🎉 Scores saved!');
}
