function showTab(tab) {
  document.querySelectorAll('.tab').forEach((t, i) => {
    t.classList.toggle('active', ['login','register','caretaker'][i] === tab);
  });
  document.getElementById('loginForm').classList.toggle('hidden', tab !== 'login');
  document.getElementById('registerForm').classList.toggle('hidden', tab !== 'register');
  document.getElementById('caretakerForm').classList.toggle('hidden', tab !== 'caretaker');
  document.getElementById('authAlert').classList.add('hidden');
}

function showAlert(msg, type = 'error') {
  const el = document.getElementById('authAlert');
  el.className = `alert alert-${type}`;
  el.textContent = msg;
  el.classList.remove('hidden');
}

async function loginPatient() {
  const email = document.getElementById('loginEmail').value.trim();
  const pwd   = document.getElementById('loginPassword').value;
  if (!email || !pwd) return showAlert('Please fill all fields.');
  try {
    const cred = await auth.signInWithEmailAndPassword(email, pwd);
    // Check role
    const snap = await db.collection('patients').doc(cred.user.uid).get();
    if (snap.exists) {
      sessionStorage.setItem('role', 'patient');
      sessionStorage.setItem('uid', cred.user.uid);
      window.location.href = 'dashboard.html';
    } else {
      showAlert('No patient record found. Are you a caretaker?');
      await auth.signOut();
    }
  } catch (e) {
    showAlert(e.message);
  }
}

async function registerPatient() {
  const name       = document.getElementById('regName').value.trim();
  const age        = document.getElementById('regAge').value;
  const email      = document.getElementById('regEmail').value.trim();
  const pwd        = document.getElementById('regPassword').value;
  const past       = document.getElementById('regPastProblems').value.trim();
  const current    = document.getElementById('regCurrentCondition').value.trim();
  const ctWA       = document.getElementById('regCaretakerWhatsApp').value.trim();
  const ctEmail    = document.getElementById('regCaretakerEmail').value.trim();

  if (!name || !age || !email || !pwd || !ctWA) return showAlert('Please fill required fields.');

  try {
    const cred = await auth.createUserWithEmailAndPassword(email, pwd);
    const uid = cred.user.uid;

    await db.collection('patients').doc(uid).set({
      uid, name, age: parseInt(age), email,
      pastProblems: past,
      currentCondition: current,
      caretakerWhatsApp: ctWA,
      caretakerEmail: ctEmail,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    // Create caretaker record
    if (ctEmail) {
      await db.collection('caretakers').doc(ctEmail).set({
        email: ctEmail,
        patients: firebase.firestore.FieldValue.arrayUnion(uid)
      }, { merge: true });
    }

    // Seed default tasks
    await seedDefaultTasks(uid);

    sessionStorage.setItem('role', 'patient');
    sessionStorage.setItem('uid', uid);
    showAlert('Account created! Redirecting...', 'success');
    setTimeout(() => window.location.href = 'dashboard.html', 1200);
  } catch (e) {
    showAlert(e.message);
  }
}

async function loginCaretaker() {
  const email = document.getElementById('ctEmail').value.trim();
  const pwd   = document.getElementById('ctPassword').value;
  if (!email || !pwd) return showAlert('Please fill all fields.');
  try {
    const cred = await auth.signInWithEmailAndPassword(email, pwd);
    const snap = await db.collection('caretakers').doc(email).get();
    if (snap.exists) {
      sessionStorage.setItem('role', 'caretaker');
      sessionStorage.setItem('uid', cred.user.uid);
      sessionStorage.setItem('ctEmail', email);
      window.location.href = 'caretaker.html';
    } else {
      showAlert('No caretaker record found.');
      await auth.signOut();
    }
  } catch (e) {
    showAlert(e.message);
  }
}

async function seedDefaultTasks(uid) {
  const today = new Date().toISOString().split('T')[0];
  const tasks = [
    {
      name: 'Morning Medicine',
      times: ['07:30', '07:35', '08:00'],
      type: 'medicine',
      completed: false,
      date: today
    },
    {
      name: 'Evening Medicine',
      times: ['17:30', '17:35', '18:00'],
      type: 'medicine',
      completed: false,
      date: today
    },
    {
      name: 'Blood Pressure Check',
      times: ['09:00'],
      type: 'health',
      completed: false,
      date: today
    },
    {
      name: 'Daily Walk / Exercise',
      times: ['08:00'],
      type: 'activity',
      completed: false,
      date: today
    }
  ];
  const batch = db.batch();
  tasks.forEach(task => {
    const ref = db.collection('tasks').doc();
    batch.set(ref, { ...task, uid, createdAt: firebase.firestore.FieldValue.serverTimestamp() });
  });
  await batch.commit();
}

// Auto-redirect if already logged in
auth.onAuthStateChanged(user => {
  if (user) {
    const role = sessionStorage.getItem('role');
    if (role === 'caretaker') window.location.href = 'caretaker.html';
    else if (role === 'patient') window.location.href = 'dashboard.html';
  }
});
