requireAuth('patient');

const uid = sessionStorage.getItem('uid');
const today = todayStr();

document.getElementById('greetingText').textContent = `${greeting()}!`;
document.getElementById('dateText').textContent = formatDate();

auth.onAuthStateChanged(async user => {
  if (!user) return;

  // Load patient info
  const patSnap = await db.collection('patients').doc(uid).get();
  const patient = patSnap.data();
  if (patient) {
    document.getElementById('patientName').textContent = `👤 ${patient.name}`;
    document.getElementById('greetingText').textContent = `${greeting()}, ${patient.name.split(' ')[0]}!`;
  }

  // Load today's tasks
  loadTasks();

  // Load today's score
  loadScore();

  // Load games status
  loadGamesStatus();
});

async function loadTasks() {
  const snap = await db.collection('tasks')
    .where('uid', '==', uid)
    .where('date', '==', today)
    .get();

  const tasks = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  const done = tasks.filter(t => t.completed).length;

  document.getElementById('taskTotal').textContent = tasks.length;
  document.getElementById('taskDone').textContent = done;
  document.getElementById('taskPct').textContent = tasks.length
    ? `${Math.round(done/tasks.length*100)}% complete` : '';

  renderDashTasks(tasks.slice(0, 4));
  updateStatus(tasks);
}

function renderDashTasks(tasks) {
  const el = document.getElementById('dashTaskList');
  if (!tasks.length) {
    el.innerHTML = '<p class="text-muted">No tasks today. <a href="tasks.html">Add tasks</a></p>';
    return;
  }
  el.innerHTML = tasks.map(t => `
    <div class="task-item ${t.completed ? 'completed' : 'pending'}" id="task_${t.id}">
      <div class="task-check ${t.completed ? 'checked' : ''}" onclick="toggleTask('${t.id}',${!t.completed})">
        ${t.completed ? '✓' : ''}
      </div>
      <div class="task-info">
        <div class="task-name">${t.name}</div>
        <div class="task-times-list">
          ${t.times.map(tm => `<span class="time-chip">${formatTime(tm)}</span>`).join('')}
        </div>
      </div>
      <span class="badge ${t.type === 'medicine' ? 'badge-red' : 'badge-green'}">${t.type}</span>
    </div>
  `).join('');
}

async function toggleTask(taskId, val) {
  await db.collection('tasks').doc(taskId).update({
    completed: val,
    completedAt: val ? new Date().toISOString() : null
  });
  loadTasks();
  if (val) showToast('✅ Task marked complete!');
}

function updateStatus(tasks) {
  const done = tasks.filter(t => t.completed).length;
  const pct = tasks.length ? done / tasks.length : 0;
  let emoji = '🟡', text = 'In progress';
  if (pct === 1) { emoji = '🟢'; text = 'All done! Great job!'; }
  else if (pct >= 0.5) { emoji = '🟡'; text = 'Keep going!'; }
  else if (tasks.length > 0 && pct < 0.3) { emoji = '🔴'; text = 'Needs attention'; }
  document.getElementById('statusEmoji').textContent = emoji;
  document.getElementById('statusText').textContent = text;
}

async function loadScore() {
  const snap = await db.collection('scores')
    .where('uid', '==', uid)
    .where('date', '==', today)
    .get();

  if (snap.empty) {
    document.getElementById('todayScore').textContent = '—';
    document.getElementById('scoreTrend').textContent = 'No games yet';
    return;
  }

  const score = snap.docs[0].data();
  document.getElementById('todayScore').textContent = score.total || 0;

  // Check yesterday
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yStr = yesterday.toISOString().split('T')[0];
  const ySnap = await db.collection('scores')
    .where('uid', '==', uid)
    .where('date', '==', yStr)
    .get();

  if (!ySnap.empty) {
    const yScore = ySnap.docs[0].data().total || 0;
    const diff = (score.total || 0) - yScore;
    if (diff > 0) document.getElementById('scoreTrend').textContent = `▲ Improving (+${diff})`;
    else if (diff < 0) document.getElementById('scoreTrend').textContent = `▼ Declining (${diff})`;
    else document.getElementById('scoreTrend').textContent = '→ Stable';
  } else {
    document.getElementById('scoreTrend').textContent = 'First day recorded';
  }
}

async function loadGamesStatus() {
  const snap = await db.collection('scores')
    .where('uid', '==', uid)
    .where('date', '==', today)
    .get();

  const el = document.getElementById('gamesStatus');
  const games = [
    { name: 'Reaction Time Test', icon: '⚡' },
    { name: 'Memory Game', icon: '🧠' },
    { name: 'Image Recognition', icon: '👁️' }
  ];

  if (!snap.empty) {
    const score = snap.docs[0].data();
    el.innerHTML = `
      <div style="margin-bottom:16px">
        ${games.map((g, i) => `
          <div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--border)">
            <span style="font-size:20px">${g.icon}</span>
            <div style="flex:1">
              <div style="font-weight:600;font-size:13px">${g.name}</div>
              <div style="font-size:12px;color:var(--text-muted)">Score: ${score['game' + (i+1)] ?? '—'}</div>
            </div>
            <span class="badge badge-green">✓ Done</span>
          </div>
        `).join('')}
      </div>
      <div style="text-align:center;padding:8px 0">
        <span style="font-size:13px;color:var(--text-muted)">Today's total: </span>
        <strong style="color:var(--primary);font-size:18px">${score.total}</strong>
      </div>
    `;
  } else {
    el.innerHTML = `
      <div style="text-align:center;padding:16px 0">
        <div style="font-size:40px;margin-bottom:8px">🎮</div>
        <p style="margin-bottom:16px;color:var(--text-muted);font-size:14px">Complete today's 3 games to track your cognitive health</p>
        <a href="games.html" class="btn btn-primary">Start Games</a>
      </div>
    `;
  }
}
