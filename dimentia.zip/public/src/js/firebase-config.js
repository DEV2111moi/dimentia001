// =============================
// REPLACE WITH YOUR FIREBASE CONFIG
// =============================
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
  databaseURL: "https://YOUR_PROJECT-default-rtdb.firebaseio.com"
};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();
const rtdb = firebase.database();

// FCM
let messaging = null;
try {
  messaging = firebase.messaging();
} catch (e) {
  console.warn("FCM not supported in this browser");
}

export { auth, db, rtdb, messaging };
