requireAuth('patient');

const uid = sessionStorage.getItem('uid');
const today = todayStr();
document.getElementById('taskDate').textContent = formatDate();

let tasksCache = [];

auth.onAuthStateChanged(user => {
  if (!user) return;
  loadAllTasks();
  // Check for missed tasks every 5 minutes
  setInterval(checkMissedTasks, 5 * 60 * 1000);
  checkMissedTasks();
});

async function loadAllTasks() {
  const snap = await db.collection('tasks')
    .where('uid', '==', uid)
    .where('date', '==', today)
    .orderBy('createdAt')
    .get();

  tasksCache = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  renderAllTasks(tasksCache);
}

function renderAllTasks(tasks) {
  const el = document.getElementById('fullTaskList');
  if (!tasks.length) {
    el.innerHTML = '<p class="text-muted" style="padding:20px 0">No tasks for today. Add some using the button above.</p>';
    return;
  }
  el.innerHTML = tasks.map(t => {
    const now = new Date();
    const lastTime = t.times[t.times.length - 1];
    const [lh, lm] = lastTime.split(':').map(Number);
    const dueDate = new Date();
    dueDate.setHours(lh, lm + 15, 0, 0);
    const isMissed = !t.completed && now > dueDate;

    return `
      <div class="task-item ${t.completed ? 'completed' : isMissed ? 'missed' : 'pending'}" id="task_${t.id}">
        <div class="task-check ${t.completed ? 'checked' : ''}" onclick="toggleTask('${t.id}', ${!t.completed})">
          ${t.completed ? '✓' : ''}
        </div>
        <div class="task-info">
          <div class="task-name">${t.name}</div>
          <div class="task-times-list">
            ${t.times.map(tm => `<span class="time-chip">⏰ ${formatTime(tm)}</span>`).join('')}
          </div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px">
          <span class="badge ${t.type === 'medicine' ? 'badge-red' : 'badge-green'}">${typeLabel(t.type)}</span>
          ${isMissed ? '<span class="badge badge-yellow">⚠️ Missed</span>' : ''}
          ${t.completed ? '<span class="badge badge-gray" style="font-size:11px">' + (t.completedAt ? new Date(t.completedAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) : 'Done') + '</span>' : ''}
        </div>
        <button class="btn btn-sm btn-outline" style="margin-left:8px" onclick="deleteTask('${t.id}')">🗑</button>
      </div>
    `;
  }).join('');
}

function typeLabel(type) {
  const map = { medicine: '💊 Medicine', health: '🩺 Health', activity: '🏃 Activity', other: '📋 Other' };
  return map[type] || type;
}

async function toggleTask(taskId, val) {
  await db.collection('tasks').doc(taskId).update({
    completed: val,
    completedAt: val ? new Date().toISOString() : null
  });
  showToast(val ? '✅ Task completed!' : '↩️ Task unmarked');
  loadAllTasks();
}

async function deleteTask(taskId) {
  if (!confirm('Delete this task?')) return;
  await db.collection('tasks').doc(taskId).delete();
  showToast('🗑 Task deleted');
  loadAllTasks();
}

async function addTask() {
  const name  = document.getElementById('newTaskName').value.trim();
  const type  = document.getElementById('newTaskType').value;
  const rawTimes = document.getElementById('newTaskTimes').value.trim();
  const errEl = document.getElementById('addTaskErr');
  errEl.classList.add('hidden');

  if (!name || !rawTimes) {
    errEl.textContent = 'Please fill name and times.';
    errEl.classList.remove('hidden');
    return;
  }

  const times = rawTimes.split(',').map(s => s.trim()).filter(s => /^\d{2}:\d{2}$/.test(s));
  if (!times.length) {
    errEl.textContent = 'Invalid time format. Use HH:MM (e.g. 07:30)';
    errEl.classList.remove('hidden');
    return;
  }

  await db.collection('tasks').add({
    uid, name, type, times,
    completed: false,
    date: today,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  });

  document.getElementById('addTaskModal').classList.add('hidden');
  document.getElementById('newTaskName').value = '';
  document.getElementById('newTaskTimes').value = '';
  showToast('📋 Task added!');
  loadAllTasks();
}

// Check for missed tasks and queue WhatsApp alerts
async function checkMissedTasks() {
  const now = new Date();
  const snap = await db.collection('tasks')
    .where('uid', '==', uid)
    .where('date', '==', today)
    .where('completed', '==', false)
    .get();

  const alertArea = document.getElementById('taskAlertArea');
  const missed = [];

  snap.docs.forEach(doc => {
    const t = doc.data();
    const lastTime = t.times[t.times.length - 1];
    const [lh, lm] = lastTime.split(':').map(Number);
    const dueDate = new Date();
    dueDate.setHours(lh, lm + 15, 0, 0);

    if (now > dueDate && !t.alertSent) {
      missed.push({ id: doc.id, ...t });
      // Mark alert as sent
      db.collection('tasks').doc(doc.id).update({ alertSent: true });
      // Queue WhatsApp alert
      triggerWhatsApp(uid, 'missed_task', { taskName: t.name, dueTime: lastTime });
    }
  });

  if (missed.length) {
    alertArea.innerHTML = `
      <div class="alert alert-warning">
        ⚠️ ${missed.length} task(s) missed: ${missed.map(t => t.name).join(', ')}. Your caretaker has been notified.
      </div>
    `;
  }
}
