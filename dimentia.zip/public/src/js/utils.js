// ---- AUTH GUARD ----
function requireAuth(role = 'patient') {
  auth.onAuthStateChanged(user => {
    if (!user) { window.location.href = 'index.html'; return; }
    const storedRole = sessionStorage.getItem('role');
    if (role === 'caretaker' && storedRole !== 'caretaker') {
      window.location.href = 'index.html';
    } else if (role === 'patient' && storedRole !== 'patient') {
      window.location.href = 'index.html';
    }
  });
}

// ---- TOAST ----
function showToast(msg, duration = 3000) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), duration);
}

// ---- DATE HELPERS ----
function todayStr() {
  return new Date().toISOString().split('T')[0];
}

function formatTime(t) {
  const [h, m] = t.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  return `${h % 12 || 12}:${m.toString().padStart(2,'0')} ${ampm}`;
}

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

function formatDate(d = new Date()) {
  return d.toLocaleDateString('en-US', { weekday:'long', year:'numeric', month:'long', day:'numeric' });
}

// ---- LOGOUT ----
function logout() {
  auth.signOut().then(() => {
    sessionStorage.clear();
    window.location.href = 'index.html';
  });
}

// ---- TWILIO WHATSAPP ----
// Called from backend (functions/index.js). This is a helper reference only.
// All Twilio calls happen server-side for security.
async function triggerWhatsApp(patientUid, type, payload) {
  // In production: call your Cloud Function endpoint
  // For demo: log to Firestore queue and let CF handle it
  await db.collection('whatsapp_queue').add({
    patientUid, type, payload,
    sentAt: null,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  });
}
