requireAuth('patient');

const uid = sessionStorage.getItem('uid');

auth.onAuthStateChanged(async user => {
  if (!user) return;
  loadScores();
});

async function loadScores() {
  const snap = await db.collection('scores')
    .where('uid', '==', uid)
    .orderBy('date', 'desc')
    .limit(30)
    .get();

  const records = snap.docs.map(d => d.data());

  if (!records.length) {
    document.getElementById('progressStats').innerHTML = '<p class="text-muted">No game scores yet. Play your first game!</p>';
    document.getElementById('historyBody').innerHTML = '<tr><td colspan="6" class="text-muted">No records</td></tr>';
    return;
  }

  // Stats
  const totals = records.map(r => r.total || 0);
  const avg = Math.round(totals.reduce((a,b) => a+b, 0) / totals.length);
  const best = Math.max(...totals);
  const latest = records[0];
  const prev = records[1];
  let trendLabel = '—', trendClass = 'badge-gray';
  if (prev) {
    const diff = (latest.total || 0) - (prev.total || 0);
    if (diff > 5) { trendLabel = '▲ Improving'; trendClass = 'badge-green'; }
    else if (diff < -5) { trendLabel = '▼ Declining'; trendClass = 'badge-red'; }
    else { trendLabel = '→ Stable'; trendClass = 'badge-gray'; }
  }

  document.getElementById('progressStats').innerHTML = `
    <div class="stat-card">
      <div class="stat-label">Latest Score</div>
      <div class="stat-value">${latest.total || 0}</div>
      <div class="stat-sub">${latest.date}</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Best Score</div>
      <div class="stat-value">${best}</div>
      <div class="stat-sub">all time</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Average</div>
      <div class="stat-value">${avg}</div>
      <div class="stat-sub">last ${records.length} sessions</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Trend</div>
      <div class="stat-value" style="font-size:18px;margin-top:8px">
        <span class="badge ${trendClass}">${trendLabel}</span>
      </div>
    </div>
  `;

  // Chart (last 7)
  renderChart(records.slice(0, 7).reverse());

  // Table
  const tbody = document.getElementById('historyBody');
  tbody.innerHTML = records.map((r, i) => {
    const prev = records[i + 1];
    let trend = '—', cls = 'badge-gray';
    if (prev) {
      const d = (r.total || 0) - (prev.total || 0);
      if (d > 5) { trend = '▲ Up'; cls = 'badge-green'; }
      else if (d < -5) { trend = '▼ Down'; cls = 'badge-red'; }
      else { trend = '→ Same'; cls = 'badge-gray'; }
    }
    return `
      <tr>
        <td>${r.date}</td>
        <td>${r.game1 ?? '—'}</td>
        <td>${r.game2 ?? '—'}</td>
        <td>${r.game3 ?? '—'}</td>
        <td><strong>${r.total ?? '—'}</strong></td>
        <td><span class="badge ${cls}">${trend}</span></td>
      </tr>
    `;
  }).join('');
}

function renderChart(data) {
  const wrap = document.getElementById('chartWrap');
  if (!data.length) { wrap.innerHTML = '<p class="text-muted">No data</p>'; return; }

  const max = Math.max(...data.map(r => r.total || 0), 1);
  wrap.innerHTML = data.map(r => {
    const pct = ((r.total || 0) / max) * 100;
    const shortDate = r.date ? r.date.slice(5) : '';
    return `
      <div class="chart-bar-col">
        <span style="font-size:11px;color:var(--text-muted)">${r.total || 0}</span>
        <div class="chart-bar" style="height:${pct}%"></div>
        <div class="chart-bar-label">${shortDate}</div>
      </div>
    `;
  }).join('');
}
