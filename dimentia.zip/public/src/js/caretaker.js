requireAuth('caretaker');

const ctEmail = sessionStorage.getItem('ctEmail');
const today = todayStr();
let patientIds = [];
let patientsData = [];

document.getElementById('ctDate').textContent = formatDate();

auth.onAuthStateChanged(async user => {
  if (!user) return;
  loadDashboard();
});

async function loadDashboard() {
  const ctSnap = await db.collection('caretakers').doc(ctEmail).get();
  if (!ctSnap.exists) { showToast('No caretaker record found'); return; }
  patientIds = ctSnap.data().patients || [];

  if (!patientIds.length) {
    document.getElementById('ctStats').innerHTML = '<p class="text-muted">No patients linked yet. Ask patients to register with your email.</p>';
    document.getElementById('patientCards').innerHTML = '<p class="text-muted">No patients linked.</p>';
    return;
  }

  // Load all patients
  const patSnaps = await Promise.all(patientIds.map(id => db.collection('patients').doc(id).get()));
  patientsData = patSnaps.filter(s => s.exists).map(s => ({ id: s.id, ...s.data() }));

  // Load today's scores for all
  const scoreSnaps = await Promise.all(
    patientIds.map(id =>
      db.collection('scores').where('uid','==',id).where('date','==',today).get()
    )
  );

  // Load tasks
  const taskSnaps = await Promise.all(
    patientIds.map(id =>
      db.collection('tasks').where('uid','==',id).where('date','==',today).get()
    )
  );

  const scoresToday = scoreSnaps.map(s => s.empty ? null : s.docs[0].data());
  const tasksToday = taskSnaps.map(s => s.docs.map(d => d.data()));

  // Stats
  const doneGames = scoresToday.filter(Boolean).length;
  const allTasks = tasksToday.flat();
  const completedTasks = allTasks.filter(t => t.completed).length;

  document.getElementById('ctStats').innerHTML = `
    <div class="stat-card">
      <div class="stat-label">Total Patients</div>
      <div class="stat-value">${patientsData.length}</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Games Done Today</div>
      <div class="stat-value">${doneGames} / ${patientsData.length}</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Tasks Completed</div>
      <div class="stat-value">${completedTasks} / ${allTasks.length}</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Missed Tasks</div>
      <div class="stat-value" style="color:var(--accent)">${allTasks.filter(t => !t.completed && t.alertSent).length}</div>
    </div>
  `;

  // Patient cards
  document.getElementById('patientCards').innerHTML = patientsData.map((p, i) => {
    const score = scoresToday[i];
    const tasks = tasksToday[i];
    const done = tasks.filter(t => t.completed).length;
    const missed = tasks.filter(t => !t.completed && t.alertSent).length;

    return `
      <div style="padding:16px;border:1px solid var(--border);border-radius:var(--radius-sm);margin-bottom:10px">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
          <div>
            <strong style="font-size:16px">${p.name}</strong>
            <span class="text-muted" style="margin-left:8px">Age ${p.age}</span>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            ${score ? `<span class="badge badge-green">🎮 Score: ${score.total}</span>` : '<span class="badge badge-gray">No games today</span>'}
            <span class="badge badge-green">✅ ${done}/${tasks.length} tasks</span>
            ${missed ? `<span class="badge badge-red">⚠️ ${missed} missed</span>` : ''}
          </div>
          <button class="btn btn-outline btn-sm" onclick="openPatient('${p.id}')">View Details</button>
        </div>
        <div style="margin-top:8px;font-size:13px;color:var(--text-muted)">
          📱 ${p.caretakerWhatsApp} &nbsp;|&nbsp; 🏥 ${p.currentCondition || 'N/A'}
        </div>
      </div>
    `;
  }).join('');

  loadAlerts();
}

async function openPatient(patId) {
  const p = patientsData.find(x => x.id === patId);
  document.getElementById('modalPatientName').textContent = p.name;

  // Load last 7 days scores
  const scoresnap = await db.collection('scores')
    .where('uid', '==', patId)
    .orderBy('date', 'desc')
    .limit(7)
    .get();
  const scores = scoresnap.docs.map(d => d.data());

  // Load today tasks
  const taskSnap = await db.collection('tasks')
    .where('uid', '==', patId)
    .where('date', '==', today)
    .get();
  const tasks = taskSnap.docs.map(d => d.data());

  document.getElementById('modalContent').innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
      <div><strong>Age:</strong> ${p.age}</div>
      <div><strong>WhatsApp:</strong> ${p.caretakerWhatsApp}</div>
      <div><strong>Past Problems:</strong> ${p.pastProblems || 'N/A'}</div>
      <div><strong>Current Condition:</strong> ${p.currentCondition || 'N/A'}</div>
    </div>
    <hr class="divider">
    <h3 style="margin-bottom:12px">Today's Tasks</h3>
    ${tasks.length ? tasks.map(t => `
      <div style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid var(--border)">
        <span>${t.completed ? '✅' : t.alertSent ? '⚠️' : '⏳'}</span>
        <span style="flex:1;font-size:14px">${t.name}</span>
        <span class="text-muted" style="font-size:12px">${t.times.join(', ')}</span>
        <span class="badge ${t.completed ? 'badge-green' : t.alertSent ? 'badge-red' : 'badge-gray'}">${t.completed ? 'Done' : t.alertSent ? 'Missed' : 'Pending'}</span>
      </div>
    `).join('') : '<p class="text-muted">No tasks today</p>'}

    <hr class="divider">
    <h3 style="margin-bottom:12px">Score History</h3>
    ${scores.length ? `
      <table class="data-table">
        <thead><tr><th>Date</th><th>Reaction</th><th>Memory</th><th>Recognition</th><th>Total</th></tr></thead>
        <tbody>
          ${scores.map(s => `
            <tr>
              <td>${s.date}</td><td>${s.game1??'—'}</td><td>${s.game2??'—'}</td><td>${s.game3??'—'}</td>
              <td><strong>${s.total??'—'}</strong></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    ` : '<p class="text-muted">No scores recorded</p>'}
  `;

  document.getElementById('patientModal').classList.remove('hidden');
}

async function loadAlerts() {
  const alertSnaps = await db.collection('whatsapp_queue')
    .where('type', '==', 'missed_task')
    .orderBy('createdAt', 'desc')
    .limit(20)
    .get();

  const alerts = alertSnaps.docs.map(d => ({ id: d.id, ...d.data() }));
  const filtered = alerts.filter(a => patientIds.includes(a.patientUid));

  const el = document.getElementById('alertsList');
  if (!filtered.length) {
    el.innerHTML = '<p class="text-muted">No missed task alerts. All tasks being completed!</p>';
    return;
  }

  el.innerHTML = filtered.map(a => {
    const p = patientsData.find(x => x.id === a.patientUid);
    const ts = a.createdAt?.toDate ? a.createdAt.toDate().toLocaleString() : 'Unknown time';
    return `
      <div style="display:flex;align-items:center;gap:12px;padding:12px;border:1px solid #fca5a5;background:#fff1f2;border-radius:var(--radius-sm);margin-bottom:8px">
        <span style="font-size:24px">⚠️</span>
        <div style="flex:1">
          <strong>${p?.name || a.patientUid}</strong> missed task: <strong>${a.payload?.taskName}</strong>
          <div class="text-muted" style="font-size:12px;margin-top:2px">Due: ${a.payload?.dueTime} &nbsp;|&nbsp; ${ts}</div>
        </div>
        <span class="badge ${a.sentAt ? 'badge-green' : 'badge-yellow'}">${a.sentAt ? '✓ Sent' : '⏳ Queued'}</span>
      </div>
    `;
  }).join('');
}

function showSection(s) {
  document.getElementById('sectionPatients').classList.toggle('hidden', s !== 'patients');
  document.getElementById('sectionAlerts').classList.toggle('hidden', s !== 'alerts');
  if (s === 'alerts') loadAlerts();
}
