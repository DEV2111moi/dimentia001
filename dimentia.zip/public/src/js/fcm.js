// src/js/fcm.js
// Include this on dashboard.html after firebase-init.js
// Requests notification permission and saves token to Firestore

const VAPID_KEY = 'YOUR_VAPID_KEY'; // From Firebase Console > Project Settings > Cloud Messaging

async function initFCM(uid) {
  if (!('Notification' in window)) return;
  if (!firebase.messaging) return;

  try {
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') return;

    // Register service worker
    const reg = await navigator.serviceWorker.register('/firebase-messaging-sw.js');
    const messaging = firebase.messaging();
    const token = await messaging.getToken({ vapidKey: VAPID_KEY, serviceWorkerRegistration: reg });

    if (token) {
      await db.collection('patients').doc(uid).update({ fcmToken: token });
      console.log('FCM token saved');
    }

    // Handle foreground messages
    messaging.onMessage(payload => {
      const { title, body } = payload.notification || {};
      showToast(`🔔 ${title}: ${body}`);
    });
  } catch (err) {
    console.warn('FCM init error:', err.message);
  }
}
