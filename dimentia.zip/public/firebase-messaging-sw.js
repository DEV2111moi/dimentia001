// public/firebase-messaging-sw.js
// Firebase Cloud Messaging Service Worker

importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-messaging-compat.js');

// REPLACE with your config
firebase.initializeApp({
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
});

const messaging = firebase.messaging();

// Handle background messages
messaging.onBackgroundMessage(payload => {
  const { title, body } = payload.notification;
  self.registration.showNotification(title, {
    body,
    icon: '/icon.png',
    badge: '/badge.png',
    tag: 'caretrack-reminder',
    requireInteraction: true,
    actions: [
      { action: 'done', title: '✅ Mark Done' },
      { action: 'snooze', title: '⏰ Snooze 5min' }
    ]
  });
});

// Notification click handler
self.addEventListener('notificationclick', event => {
  event.notification.close();
  if (event.action === 'done') {
    // Open tasks page
    event.waitUntil(clients.openWindow('/tasks.html'));
  } else {
    event.waitUntil(clients.openWindow('/dashboard.html'));
  }
});
