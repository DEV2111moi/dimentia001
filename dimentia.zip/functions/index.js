const functions = require('firebase-functions');
const admin = require('firebase-admin');
const twilio = require('twilio');

admin.initializeApp();
const db = admin.firestore();

// ================================================================
// CONFIG — Set these in Firebase environment or replace directly
// ================================================================
// firebase functions:config:set twilio.sid="ACxxx" twilio.token="xxx" twilio.from="whatsapp:+14155238886"
const TWILIO_SID   = functions.config().twilio?.sid   || 'YOUR_TWILIO_ACCOUNT_SID';
const TWILIO_TOKEN = functions.config().twilio?.token || 'YOUR_TWILIO_AUTH_TOKEN';
const TWILIO_FROM  = functions.config().twilio?.from  || 'whatsapp:+14155238886'; // Twilio sandbox number

// ================================================================
// HELPER: Send WhatsApp via Twilio
// ================================================================
async function sendWhatsApp(to, body) {
  const client = twilio(TWILIO_SID, TWILIO_TOKEN);
  const toNum = to.startsWith('whatsapp:') ? to : `whatsapp:${to}`;
  try {
    const msg = await client.messages.create({ from: TWILIO_FROM, to: toNum, body });
    console.log(`WhatsApp sent to ${to}: ${msg.sid}`);
    return msg.sid;
  } catch (err) {
    console.error('Twilio error:', err.message);
    throw err;
  }
}

// ================================================================
// FUNCTION 1: Process WhatsApp Queue
// Runs every 5 minutes, picks up unsent messages
// ================================================================
exports.processWhatsAppQueue = functions.pubsub
  .schedule('every 5 minutes')
  .onRun(async context => {
    const snapshot = await db.collection('whatsapp_queue')
      .where('sentAt', '==', null)
      .limit(20)
      .get();

    if (snapshot.empty) return null;

    for (const doc of snapshot.docs) {
      const data = doc.data();
      try {
        const patSnap = await db.collection('patients').doc(data.patientUid).get();
        if (!patSnap.exists) continue;
        const patient = patSnap.data();
        const to = patient.caretakerWhatsApp;
        if (!to) continue;

        let body = '';

        if (data.type === 'missed_task') {
          body = formatMissedTaskMessage(patient.name, data.payload);
        } else if (data.type === 'daily_report') {
          body = await formatDailyReport(patient, data.payload);
        } else {
          body = `CareTrack Alert for ${patient.name}: ${JSON.stringify(data.payload)}`;
        }

        await sendWhatsApp(to, body);
        await doc.ref.update({ sentAt: admin.firestore.FieldValue.serverTimestamp() });
      } catch (err) {
        console.error('Queue item error:', doc.id, err.message);
        await doc.ref.update({ error: err.message });
      }
    }
    return null;
  });

// ================================================================
// FUNCTION 2: Medicine Reminders
// Checks every minute for upcoming medicine times
// ================================================================
exports.sendMedicineReminders = functions.pubsub
  .schedule('every 1 minutes')
  .onRun(async context => {
    const now = new Date();
    const hh = now.getHours().toString().padStart(2, '0');
    const mm = now.getMinutes().toString().padStart(2, '0');
    const currentTime = `${hh}:${mm}`;
    const today = now.toISOString().split('T')[0];

    // Find tasks due at current time that are not completed
    const taskSnap = await db.collection('tasks')
      .where('date', '==', today)
      .where('completed', '==', false)
      .where('times', 'array-contains', currentTime)
      .get();

    for (const doc of taskSnap.docs) {
      const task = doc.data();
      try {
        const patSnap = await db.collection('patients').doc(task.uid).get();
        if (!patSnap.exists) continue;
        const patient = patSnap.data();

        // FCM push to patient (if token stored)
        if (patient.fcmToken) {
          await admin.messaging().send({
            token: patient.fcmToken,
            notification: {
              title: `⏰ Reminder: ${task.name}`,
              body: `It's time for your ${task.name}. Please take it now.`
            },
            data: { taskId: doc.id, taskName: task.name }
          });
        }

        // Also WhatsApp to caretaker for medicine tasks
        if (task.type === 'medicine' && patient.caretakerWhatsApp) {
          const body = `⏰ *CareTrack Reminder*\n\nPatient: *${patient.name}*\nTask: *${task.name}*\nScheduled: ${currentTime}\n\nPlease ensure the patient takes their medicine.`;
          await sendWhatsApp(patient.caretakerWhatsApp, body);
        }
      } catch (err) {
        console.error('Reminder error:', doc.id, err.message);
      }
    }
    return null;
  });

// ================================================================
// FUNCTION 3: Missed Task Check (runs every 15 minutes)
// ================================================================
exports.checkMissedTasks = functions.pubsub
  .schedule('every 15 minutes')
  .onRun(async context => {
    const now = new Date();
    const today = now.toISOString().split('T')[0];

    const taskSnap = await db.collection('tasks')
      .where('date', '==', today)
      .where('completed', '==', false)
      .where('alertSent', '==', false)
      .get();

    for (const doc of taskSnap.docs) {
      const task = doc.data();
      const lastTime = task.times[task.times.length - 1];
      const [lh, lm] = lastTime.split(':').map(Number);
      const due = new Date();
      due.setHours(lh, lm + 15, 0, 0);

      if (now > due) {
        try {
          const patSnap = await db.collection('patients').doc(task.uid).get();
          if (!patSnap.exists) continue;
          const patient = patSnap.data();

          if (patient.caretakerWhatsApp) {
            const body = formatMissedTaskMessage(patient.name, { taskName: task.name, dueTime: lastTime });
            await sendWhatsApp(patient.caretakerWhatsApp, body);
          }

          await doc.ref.update({ alertSent: true });
          console.log(`Missed task alert sent for ${patient.name}: ${task.name}`);
        } catch (err) {
          console.error('Missed task error:', doc.id, err.message);
        }
      }
    }
    return null;
  });

// ================================================================
// FUNCTION 4: Daily Report (runs at 8 PM every day)
// ================================================================
exports.sendDailyReport = functions.pubsub
  .schedule('0 20 * * *')
  .timeZone('Asia/Kolkata')
  .onRun(async context => {
    const today = new Date().toISOString().split('T')[0];
    const patSnap = await db.collection('patients').get();

    for (const doc of patSnap.docs) {
      const patient = doc.data();
      if (!patient.caretakerWhatsApp) continue;

      try {
        const scoreSnap = await db.collection('scores')
          .where('uid', '==', doc.id)
          .where('date', '==', today)
          .get();

        const taskSnap = await db.collection('tasks')
          .where('uid', '==', doc.id)
          .where('date', '==', today)
          .get();

        const tasks = taskSnap.docs.map(d => d.data());
        const done = tasks.filter(t => t.completed).length;
        const score = scoreSnap.empty ? null : scoreSnap.docs[0].data();

        let body = `📋 *CareTrack Daily Report*\n`;
        body += `Date: ${today}\n`;
        body += `Patient: *${patient.name}* (Age ${patient.age})\n\n`;

        body += `✅ *Tasks:* ${done}/${tasks.length} completed\n`;
        if (tasks.filter(t => !t.completed).length) {
          body += `⚠️ Missed: ${tasks.filter(t => !t.completed).map(t => t.name).join(', ')}\n`;
        }
        body += `\n`;

        if (score) {
          body += `🎮 *Cognitive Games:*\n`;
          body += `  ⚡ Reaction: ${score.game1}\n`;
          body += `  🧠 Memory: ${score.game2}\n`;
          body += `  👁️ Recognition: ${score.game3}\n`;
          body += `  📊 Total: *${score.total}*\n\n`;

          // Trend
          const yesterday = new Date();
          yesterday.setDate(yesterday.getDate() - 1);
          const yStr = yesterday.toISOString().split('T')[0];
          const ySnap = await db.collection('scores')
            .where('uid', '==', doc.id).where('date', '==', yStr).get();

          if (!ySnap.empty) {
            const diff = score.total - (ySnap.docs[0].data().total || 0);
            if (diff > 5) body += `📈 Trend: *Improving* (+${diff})\n`;
            else if (diff < -5) body += `📉 Trend: *Declining* (${diff})\n`;
            else body += `➡️ Trend: *Stable*\n`;
          }
        } else {
          body += `🎮 *Games:* Not completed today\n`;
        }

        body += `\n_Sent by CareTrack Dementia Care System_`;
        await sendWhatsApp(patient.caretakerWhatsApp, body);
        console.log(`Daily report sent for ${patient.name}`);
      } catch (err) {
        console.error('Daily report error:', doc.id, err.message);
      }
    }
    return null;
  });

// ================================================================
// FUNCTION 5: HTTP endpoint — Save FCM Token
// ================================================================
exports.saveFcmToken = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Login required');
  const { token } = data;
  if (!token) throw new functions.https.HttpsError('invalid-argument', 'Token required');
  await db.collection('patients').doc(context.auth.uid).update({ fcmToken: token });
  return { success: true };
});

// ================================================================
// HELPERS
// ================================================================
function formatMissedTaskMessage(patientName, payload) {
  return `🚨 *CareTrack ALERT*\n\nPatient: *${patientName}*\nMissed Task: *${payload.taskName}*\nScheduled: ${payload.dueTime}\n\nThis task was not completed within 15 minutes of the due time.\n\nPlease check on the patient immediately.\n\n_Sent by CareTrack_`;
}

async function formatDailyReport(patient, payload) {
  let body = `📋 *CareTrack Daily Report*\n`;
  body += `Patient: *${patient.name}*\nDate: ${payload.date}\n\n`;
  body += `🎮 *Game Scores:*\n`;
  body += `  ⚡ Reaction: ${payload.game1}\n`;
  body += `  🧠 Memory: ${payload.game2}\n`;
  body += `  👁️ Recognition: ${payload.game3}\n`;
  body += `  📊 Total: *${payload.total}*\n`;
  body += `\n_Sent by CareTrack_`;
  return body;
}
